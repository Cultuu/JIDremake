# Contact Information

Financial planner and data cruncher living in Idaho, California refugee. Three children and a fourth on the way. My wife is the light of my life. I have broad programming skills, I write, and I analyze data. Industry veteran in all three. 

I will provide my services to any Republican in a competitive office on a volunteer basis for the 2020 Election. 

If interested, email me with proof of identity along with your expectations to jsmithrand016 (at) gmail (dot) com. 
  
 