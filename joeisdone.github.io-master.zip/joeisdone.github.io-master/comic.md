[Home](https://joeisdone.github.io)

I created a comic that hopefully simplifies the logic behind [joeisdone](https://joeisdone.github.io) a bit. 

![Page 1](/images/BP1.jpg)
------
![Page 2](/images/BP2.jpg)
------
![Page 3](/images/BP3.jpg)
------
![Page 4](/images/BP4.jpg)
------
![Page 5](/images/BP5.jpg)
------
![Page 6](/images/BP6.jpg)
------
![Page 7](/images/BP7.jpg)
------
![Page 8](/images/BP8.jpg)
