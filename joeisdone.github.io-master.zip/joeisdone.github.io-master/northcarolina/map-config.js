﻿var usncjsconfig = {
  "usncjs1":{
    "hover": "ALAMANCE",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs2":{
    "hover": "ALEXANDER",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs3":{
    "hover": "ALLEGHANY",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs4":{
    "hover": "ANSON",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs5":{
    "hover": "ASHE",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs6":{
    "hover": "AVERY",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs7":{
    "hover": "BEAUFORT",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs8":{
    "hover": "BERTIE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs9":{
    "hover": "BLADEN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs10":{
    "hover": "BRUNSWICK",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs11":{
    "hover": "BUNCOMBE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs12":{
    "hover": "BURKE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs13":{
    "hover": "CABARRUS",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs14":{
    "hover": "CALDWELL",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs15":{
    "hover": "CAMDEN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs16":{
    "hover": "CARTERET",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs17":{
    "hover": "CASWELL",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs18":{
    "hover": "CATAWBA",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs19":{
    "hover": "CHATHAM",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs20":{
    "hover": "CHEROKEE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs21":{
    "hover": "CHOWAN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs22":{
    "hover": "CLAY",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs23":{
    "hover": "CLEVELAND",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs24":{
    "hover": "COLUMBUS",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs25":{
    "hover": "CRAVEN",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs26":{
    "hover": "CUMBERLAND",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs27":{
    "hover": "CURRITUCK",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs28":{
    "hover": "DARE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs29":{
    "hover": "DAVIDSON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs30":{
    "hover": "DAVIE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs31":{
    "hover": "DUPLIN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs32":{
    "hover": "DURHAM",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs33":{
    "hover": "EDGECOMBE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs34":{
    "hover": "FORSYTH",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs35":{
    "hover": "FRANKLIN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs36":{
    "hover": "GASTON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs37":{
    "hover": "GATES",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs38":{
    "hover": "GRAHAM",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs39":{
    "hover": "GRANVILLE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs40":{
    "hover": "GREENE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs41":{
    "hover": "GUILFORD",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs42":{
    "hover": "HALIFAX",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs43":{
    "hover": "HARNETT",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs44":{
    "hover": "HAYWOOD",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs45":{
    "hover": "HENDERSON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs46":{
    "hover": "HERTFORD",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs47":{
    "hover": "HOKE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs48":{
    "hover": "HYDE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs49":{
    "hover": "IREDELL",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs50":{
    "hover": "JACKSON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs51":{
    "hover": "JOHNSTON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs52":{
    "hover": "JONES",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs53":{
    "hover": "LEE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs54":{
    "hover": "LENOIR",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs55":{
    "hover": "LINCOLN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs56":{
    "hover": "MCDOWELL",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs57":{
    "hover": "MACON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs58":{
    "hover": "MADISON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs59":{
    "hover": "MARTIN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs60":{
    "hover": "MECKLENBURG",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs61":{
    "hover": "MITCHELL",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs62":{
    "hover": "MONTGOMERY",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs63":{
    "hover": "MOORE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs64":{
    "hover": "NASH",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs65":{
    "hover": "NEW HANOVER",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs66":{
    "hover": "NORTHAMPTON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs67":{
    "hover": "ONSLOW",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs68":{
    "hover": "ORANGE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs69":{
    "hover": "PAMLICO",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs70":{
    "hover": "PASQUOTANK",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs71":{
    "hover": "PENDER",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs72":{
    "hover": "PERQUIMANS",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs73":{
    "hover": "PERSON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs74":{
    "hover": "PITT",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs75":{
    "hover": "POLK",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs76":{
    "hover": "RANDOLPH",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs77":{
    "hover": "RICHMOND",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs78":{
    "hover": "ROBESON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs79":{
    "hover": "ROCKINGHAM",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs80":{
    "hover": "ROWAN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs81":{
    "hover": "RUTHERFORD",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs82":{
    "hover": "SAMPSON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs83":{
    "hover": "SCOTLAND",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs84":{
    "hover": "STANLY",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs85":{
    "hover": "STOKES",
	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs86":{
    "hover": "SURRY",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs87":{
    "hover": "SWAIN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs88":{
    "hover": "TRANSYLVANIA",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs89":{
    "hover": "TYRRELL",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs90":{
    "hover": "UNION",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs91":{
    "hover": "VANCE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs92":{
    "hover": "WAKE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs93":{
    "hover": "WARREN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs94":{
    "hover": "WASHINGTON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs95":{
    "hover": "WATAUGA",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs96":{
    "hover": "WAYNE",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs97":{
    "hover": "WILKES",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs98":{
    "hover": "WILSON",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs99":{
    "hover": "YADKIN",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "usncjs100":{
    "hover": "YANCEY",

	"upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true,
    "target": "none",
  },
  "general":{
    "borderColor": "#9CA8B6",
    "visibleNames": "#adadad"
  }
};